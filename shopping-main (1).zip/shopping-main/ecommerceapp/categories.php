<?php
session_start();
require_once 'config/database.php';

// Get all categories with product count
$sql = "SELECT c.*, COUNT(p.id) as product_count 
        FROM categories c 
        LEFT JOIN products p ON c.id = p.category_id 
        GROUP BY c.id";
$result = $conn->query($sql);
$categories = $result->fetch_all(MYSQLI_ASSOC);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Categories - ShopEase</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body>
    <?php include 'includes/header.php'; ?>

    <div class="container py-5">
        <h1 class="mb-4">Product Categories</h1>
        
        <div class="row g-4">
            <?php foreach($categories as $category): ?>
                <div class="col-md-4">
                    <div class="card h-100 category-card">
                        <div class="card-body text-center">
                            <?php
                            $icon = '';
                            switch($category['name']) {
                                case 'Electronics':
                                    $icon = 'fas fa-mobile-alt';
                                    break;
                                case 'Fashion':
                                    $icon = 'fas fa-tshirt';
                                    break;
                                case 'Home & Living':
                                    $icon = 'fas fa-home';
                                    break;
                                case 'Books':
                                    $icon = 'fas fa-book';
                                    break;
                                case 'Sports & Fitness':
                                    $icon = 'fas fa-running';
                                    break;
                                default:
                                    $icon = 'fas fa-shopping-bag';
                            }
                            ?>
                            <i class="<?php echo $icon; ?> fa-3x mb-3 text-primary"></i>
                            <h4 class="card-title"><?php echo $category['name']; ?></h4>
                            <p class="text-muted mb-3"><?php echo $category['description']; ?></p>
                            <p class="mb-4"><span class="badge bg-secondary"><?php echo $category['product_count']; ?> Products</span></p>
                            <a href="shop.php?category=<?php echo $category['id']; ?>" class="btn btn-outline-primary">
                                View Products
                            </a>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    </div>

    <?php include 'includes/footer.php'; ?>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
    <script src="assets/js/main.js"></script>
</body>
</html>
