document.addEventListener('DOMContentLoaded', function() {
    // Initialize tooltips
    var tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'))
    var tooltipList = tooltipTriggerList.map(function (tooltipTriggerEl) {
        return new bootstrap.Tooltip(tooltipTriggerEl)
    });

    // Add to Cart functionality
    const addToCartButtons = document.querySelectorAll('.add-to-cart');
    addToCartButtons.forEach(button => {
        button.addEventListener('click', function(e) {
            const productId = this.dataset.productId;
            addToCart(productId);
        });
    });

    // Cart functionality
    function addToCart(productId) {
        const button = document.querySelector(`[data-product-id="${productId}"]`);
        const originalText = button.innerHTML;
        button.innerHTML = '<span class="spinner-border spinner-border-sm"></span> Adding...';
        button.disabled = true;

        fetch('handlers/cart_handler.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded',
            },
            body: `action=add&product_id=${productId}`
        })
        .then(response => response.json())
        .then(data => {
            if(data.success) {
                showToast('Success', 'Product added to cart!', 'success');
                updateCartCount(data.cartCount);
            } else {
                showToast('Error', data.message || 'Failed to add product to cart', 'error');
            }
        })
        .catch(error => {
            showToast('Error', 'Something went wrong', 'error');
        })
        .finally(() => {
            button.innerHTML = originalText;
            button.disabled = false;
        });
    }

    // Update cart count
    function updateCartCount(count) {
        const cartCountElements = document.querySelectorAll('.cart-count');
        cartCountElements.forEach(element => {
            element.textContent = count;
            element.style.display = count > 0 ? 'block' : 'none';
        });
    }

    // Toast notification system
    function showToast(title, message, type = 'info') {
        const toastContainer = document.getElementById('toast-container');
        if (!toastContainer) {
            const container = document.createElement('div');
            container.id = 'toast-container';
            container.style.position = 'fixed';
            container.style.bottom = '20px';
            container.style.right = '20px';
            container.style.zIndex = '1000';
            document.body.appendChild(container);
        }

        const toast = document.createElement('div');
        toast.className = `toast align-items-center text-white bg-${type === 'error' ? 'danger' : 'success'} border-0`;
        toast.setAttribute('role', 'alert');
        toast.setAttribute('aria-live', 'assertive');
        toast.setAttribute('aria-atomic', 'true');

        toast.innerHTML = `
            <div class="d-flex">
                <div class="toast-body">
                    <strong>${title}</strong><br>
                    ${message}
                </div>
                <button type="button" class="btn-close btn-close-white me-2 m-auto" data-bs-dismiss="toast" aria-label="Close"></button>
            </div>
        `;

        document.getElementById('toast-container').appendChild(toast);
        const bsToast = new bootstrap.Toast(toast, { autohide: true, delay: 3000 });
        bsToast.show();

        toast.addEventListener('hidden.bs.toast', function () {
            toast.remove();
        });
    }

    // Quantity controls in cart
    const quantityControls = document.querySelectorAll('.quantity-control');
    quantityControls.forEach(control => {
        control.addEventListener('click', function(e) {
            const input = this.parentElement.querySelector('.quantity-input');
            const currentValue = parseInt(input.value);
            const isIncrement = this.classList.contains('increment');
            
            if(isIncrement) {
                input.value = currentValue + 1;
            } else if(currentValue > 1) {
                input.value = currentValue - 1;
            }
            
            updateCartItem(input.dataset.productId, input.value);
        });
    });

    // Update cart item quantity
    function updateCartItem(productId, quantity) {
        fetch('handlers/cart_handler.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded',
            },
            body: `action=update&product_id=${productId}&quantity=${quantity}`
        })
        .then(response => response.json())
        .then(data => {
            if(data.success) {
                updateCartTotal(data.cartTotal);
            } else {
                showToast('Error', data.message || 'Failed to update cart', 'error');
            }
        })
        .catch(error => {
            showToast('Error', 'Something went wrong', 'error');
        });
    }

    // Update cart total
    function updateCartTotal(total) {
        const cartTotalElement = document.getElementById('cart-total');
        if(cartTotalElement) {
            cartTotalElement.textContent = `$${total.toFixed(2)}`;
        }
    }

    // Form validation
    const forms = document.querySelectorAll('.needs-validation');
    forms.forEach(form => {
        form.addEventListener('submit', function(event) {
            if (!form.checkValidity()) {
                event.preventDefault();
                event.stopPropagation();
            }
            form.classList.add('was-validated');
        });
    });

    // Product image preview
    const productImages = document.querySelectorAll('.product-image');
    productImages.forEach(image => {
        image.addEventListener('click', function() {
            const modal = new bootstrap.Modal(document.getElementById('imagePreviewModal'));
            const modalImage = document.getElementById('modalImage');
            modalImage.src = this.src;
            modal.show();
        });
    });

    // Search functionality
    const searchForm = document.getElementById('searchForm');
    if(searchForm) {
        searchForm.addEventListener('submit', function(e) {
            e.preventDefault();
            const searchInput = this.querySelector('input[name="search"]');
            if(searchInput.value.trim()) {
                window.location.href = `shop.php?search=${encodeURIComponent(searchInput.value.trim())}`;
            }
        });
    }

    // Filter functionality
    const filterForm = document.getElementById('filterForm');
    if(filterForm) {
        const filterInputs = filterForm.querySelectorAll('input, select');
        filterInputs.forEach(input => {
            input.addEventListener('change', function() {
                filterForm.submit();
            });
        });
    }
});
