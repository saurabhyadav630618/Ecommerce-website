<footer class="bg-dark text-light py-4 mt-auto">
    <div class="container">
        <div class="row">
            <div class="col-md-4">
                <h5>About ShopEase</h5>
                <p>Your one-stop destination for all your shopping needs. Quality products, great prices, and excellent service.</p>
            </div>
            <div class="col-md-4">
                <h5>Quick Links</h5>
                <ul class="list-unstyled">
                    <li><a href="about.php" class="text-light">About Us</a></li>
                    <li><a href="contact.php" class="text-light">Contact Us</a></li>
                    <li><a href="privacy.php" class="text-light">Privacy Policy</a></li>
                    <li><a href="terms.php" class="text-light">Terms & Conditions</a></li>
                </ul>
            </div>
            <div class="col-md-4">
                <h5>Contact Us</h5>
                <ul class="list-unstyled">
                    <li><i class="fas fa-phone me-2"></i> +1 234 567 890</li>
                    <li><i class="fas fa-envelope me-2"></i> info@shopease.com</li>
                    <li><i class="fas fa-map-marker-alt me-2"></i> 123 Shopping Street, NY 10001</li>
                </ul>
                <div class="social-links mt-3">
                    <a href="#" class="text-light me-3"><i class="fab fa-facebook-f"></i></a>
                    <a href="#" class="text-light me-3"><i class="fab fa-twitter"></i></a>
                    <a href="#" class="text-light me-3"><i class="fab fa-instagram"></i></a>
                    <a href="#" class="text-light"><i class="fab fa-linkedin-in"></i></a>
                </div>
            </div>
        </div>
        <hr class="bg-light">
        <div class="text-center">
            <p class="mb-0">&copy; <?php echo date('Y'); ?> ShopEase. All rights reserved.</p>
        </div>
    </div>
</footer>

<!-- Toast Container -->
<div id="toast-container"></div>
