<?php
session_start();
require_once 'config/database.php';

// Get categories for filter
$categories_sql = "SELECT * FROM categories";
$categories_result = $conn->query($categories_sql);
$categories = $categories_result->fetch_all(MYSQLI_ASSOC);

// Handle filters
$category_id = isset($_GET['category']) ? $_GET['category'] : null;
$search = isset($_GET['search']) ? $_GET['search'] : null;
$sort = isset($_GET['sort']) ? $_GET['sort'] : 'name_asc';

// Build query
$sql = "SELECT p.*, c.name as category_name FROM products p 
        JOIN categories c ON p.category_id = c.id 
        WHERE 1=1";

if ($category_id) {
    $sql .= " AND p.category_id = " . intval($category_id);
}

if ($search) {
    $search = $conn->real_escape_string($search);
    $sql .= " AND (p.name LIKE '%$search%' OR p.description LIKE '%$search%')";
}

// Add sorting
switch ($sort) {
    case 'price_asc':
        $sql .= " ORDER BY p.price ASC";
        break;
    case 'price_desc':
        $sql .= " ORDER BY p.price DESC";
        break;
    case 'name_desc':
        $sql .= " ORDER BY p.name DESC";
        break;
    default:
        $sql .= " ORDER BY p.name ASC";
}

$result = $conn->query($sql);
$products = $result->fetch_all(MYSQLI_ASSOC);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Shop - ShopEase</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body>
    <?php include 'includes/header.php'; ?>

    <div class="container py-5">
        <div class="row">
            <!-- Filters -->
            <div class="col-lg-3">
                <div class="card shadow-sm mb-4">
                    <div class="card-body">
                        <h5 class="card-title mb-4">Filters</h5>
                        <form id="filterForm" method="GET" action="shop.php">
                            <?php if($search): ?>
                                <input type="hidden" name="search" value="<?php echo htmlspecialchars($search); ?>">
                            <?php endif; ?>
                            
                            <div class="mb-4">
                                <label class="form-label">Category</label>
                                <div class="form-check">
                                    <input class="form-check-input" type="radio" name="category" id="cat_all" 
                                           value="" <?php echo !$category_id ? 'checked' : ''; ?>>
                                    <label class="form-check-label" for="cat_all">All Categories</label>
                                </div>
                                <?php foreach($categories as $category): ?>
                                    <div class="form-check">
                                        <input class="form-check-input" type="radio" name="category" 
                                               id="cat_<?php echo $category['id']; ?>" 
                                               value="<?php echo $category['id']; ?>"
                                               <?php echo $category_id == $category['id'] ? 'checked' : ''; ?>>
                                        <label class="form-check-label" for="cat_<?php echo $category['id']; ?>">
                                            <?php echo $category['name']; ?>
                                        </label>
                                    </div>
                                <?php endforeach; ?>
                            </div>
                            
                            <div class="mb-4">
                                <label class="form-label">Sort By</label>
                                <select class="form-select" name="sort">
                                    <option value="name_asc" <?php echo $sort == 'name_asc' ? 'selected' : ''; ?>>Name (A-Z)</option>
                                    <option value="name_desc" <?php echo $sort == 'name_desc' ? 'selected' : ''; ?>>Name (Z-A)</option>
                                    <option value="price_asc" <?php echo $sort == 'price_asc' ? 'selected' : ''; ?>>Price (Low to High)</option>
                                    <option value="price_desc" <?php echo $sort == 'price_desc' ? 'selected' : ''; ?>>Price (High to Low)</option>
                                </select>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
            
            <!-- Products -->
            <div class="col-lg-9">
                <?php if($search): ?>
                    <h5 class="mb-4">Search Results for "<?php echo htmlspecialchars($search); ?>"</h5>
                <?php endif; ?>
                
                <?php if(empty($products)): ?>
                    <div class="text-center py-5">
                        <i class="fas fa-search fa-3x text-muted mb-3"></i>
                        <h3>No Products Found</h3>
                        <p class="text-muted">Try adjusting your search or filter to find what you're looking for.</p>
                    </div>
                <?php else: ?>
                    <div class="row g-4">
                        <?php foreach($products as $product): ?>
                            <div class="col-md-4">
                                <div class="card h-100 product-card">
                                    <img src="<?php echo $product['image_url']; ?>" 
                                         class="card-img-top" 
                                         alt="<?php echo $product['name']; ?>">
                                    <div class="card-body">
                                        <span class="badge bg-primary mb-2"><?php echo $product['category_name']; ?></span>
                                        <h5 class="card-title"><?php echo $product['name']; ?></h5>
                                        <p class="card-text text-muted"><?php echo $product['description']; ?></p>
                                        <div class="d-flex justify-content-between align-items-center">
                                            <span class="h5 mb-0">$<?php echo number_format($product['price'], 2); ?></span>
                                            <button class="btn btn-primary add-to-cart" 
                                                    data-product-id="<?php echo $product['id']; ?>">
                                                Add to Cart
                                            </button>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <?php include 'includes/footer.php'; ?>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
    <script src="assets/js/main.js"></script>
</body>
</html>
