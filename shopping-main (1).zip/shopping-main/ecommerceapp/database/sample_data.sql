-- Insert Categories
INSERT INTO categories (name, description) VALUES
('Electronics', 'Latest electronic gadgets and accessories'),
('Fashion', 'Trendy clothing and accessories for men and women'),
('Home & Living', 'Furniture and home decor items'),
('Books', 'Books across various genres'),
('Sports & Fitness', 'Sports equipment and fitness gear');

-- Insert Products
INSERT INTO products (category_id, name, description, price, image_url, stock) VALUES
-- Electronics
(1, 'Wireless Earbuds', 'High-quality wireless earbuds with noise cancellation', 129.99, 'https://images.unsplash.com/photo-1590658268037-6bf12165a8df?w=500', 50),
(1, 'Smart Watch', 'Feature-rich smartwatch with health tracking', 199.99, 'https://images.unsplash.com/photo-1523275335684-37898b6baf30?w=500', 30),
(1, 'Bluetooth Speaker', 'Portable bluetooth speaker with deep bass', 79.99, 'https://images.unsplash.com/photo-1589256469067-ea99122bbdc9?w=500', 40),
(1, '4K Action Camera', 'Waterproof action camera for adventures', 299.99, 'https://images.unsplash.com/photo-1526170375885-4d8ecf77b99f?w=500', 25),

-- Fashion
(2, 'Classic Denim Jacket', 'Stylish denim jacket for all seasons', 89.99, 'https://images.unsplash.com/photo-1523205771623-e0faa4d2813d?w=500', 100),
(2, 'Leather Sneakers', 'Comfortable and trendy sneakers', 129.99, 'https://images.unsplash.com/photo-1560769629-975ec94e6a86?w=500', 75),
(2, 'Summer Dress', 'Light and comfortable summer dress', 59.99, 'https://images.unsplash.com/photo-1496747611176-843222e1e57c?w=500', 60),
(2, 'Designer Sunglasses', 'UV protected stylish sunglasses', 149.99, 'https://images.unsplash.com/photo-1511499767150-a48a237f0083?w=500', 45),

-- Home & Living
(3, 'Modern Coffee Table', 'Elegant coffee table for your living room', 299.99, 'https://images.unsplash.com/photo-1532372320978-9b6d03df7921?w=500', 20),
(3, 'Table Lamp', 'Contemporary design table lamp', 79.99, 'https://images.unsplash.com/photo-1507473885765-e6ed057f782c?w=500', 35),
(3, 'Throw Pillows Set', 'Decorative throw pillows set of 4', 49.99, 'https://images.unsplash.com/photo-1584100936595-c0654b55a2e6?w=500', 50),
(3, 'Wall Art Canvas', 'Beautiful wall art for home decoration', 89.99, 'https://images.unsplash.com/photo-1526304640581-d334cdbbf45e?w=500', 30),

-- Books
(4, 'The Art of Coding', 'Comprehensive guide to programming', 39.99, 'https://images.unsplash.com/photo-1532012197267-da84d127e765?w=500', 100),
(4, 'Mystery Chronicles', 'Bestselling mystery novel', 24.99, 'https://images.unsplash.com/photo-1543002588-bfa74002ed7e?w=500', 80),
(4, 'Healthy Living Guide', 'Complete guide to healthy lifestyle', 29.99, 'https://images.unsplash.com/photo-1544947950-fa07a98d237f?w=500', 65),
(4, 'Business Strategy', 'Modern business strategy handbook', 34.99, 'https://images.unsplash.com/photo-1589998059171-988d887df646?w=500', 55),

-- Sports & Fitness
(5, 'Yoga Mat', 'Premium non-slip yoga mat', 39.99, 'https://images.unsplash.com/photo-1593810450967-f9c42742e326?w=500', 100),
(5, 'Resistance Bands Set', 'Complete set of resistance bands', 29.99, 'https://images.unsplash.com/photo-1598289431512-b97b0917affc?w=500', 150),
(5, 'Adjustable Dumbbells', 'Pair of adjustable weight dumbbells', 199.99, 'https://images.unsplash.com/photo-1586401100295-7a8096fd231a?w=500', 30),
(5, 'Running Shoes', 'Professional running shoes', 129.99, 'https://images.unsplash.com/photo-1542291026-7eec264c27ff?w=500', 80);
