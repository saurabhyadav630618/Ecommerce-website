<?php
session_start();
require_once 'config/database.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>About Us - ShopEase</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body>
    <?php include 'includes/header.php'; ?>

    <div class="container py-5">
        <div class="row justify-content-center">
            <div class="col-lg-8 text-center">
                <h1 class="display-4 mb-4">About ShopEase</h1>
                <p class="lead mb-5">Your trusted destination for quality products and exceptional shopping experience.</p>
            </div>
        </div>

        <div class="row mb-5">
            <div class="col-md-6">
                <img src="https://images.unsplash.com/photo-1578916171728-46686eac8d58?w=800" 
                     alt="About ShopEase" 
                     class="img-fluid rounded shadow-sm">
            </div>
            <div class="col-md-6">
                <h3 class="mb-4">Our Story</h3>
                <p>Founded in 2024, ShopEase has grown from a small online store to one of the leading e-commerce platforms. Our journey began with a simple mission: to make quality products accessible to everyone while providing an exceptional shopping experience.</p>
                <p>Today, we serve thousands of customers, offering a wide range of products across various categories. Our commitment to quality, customer satisfaction, and continuous innovation has made us a trusted name in the e-commerce industry.</p>
                <div class="row g-4 mt-4">
                    <div class="col-6">
                        <div class="d-flex align-items-center">
                            <i class="fas fa-users fa-2x text-primary me-3"></i>
                            <div>
                                <h4 class="h5 mb-1">10K+</h4>
                                <p class="text-muted mb-0">Happy Customers</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-6">
                        <div class="d-flex align-items-center">
                            <i class="fas fa-shopping-bag fa-2x text-primary me-3"></i>
                            <div>
                                <h4 class="h5 mb-1">50K+</h4>
                                <p class="text-muted mb-0">Products Sold</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="row mb-5">
            <div class="col-lg-12 text-center">
                <h3 class="mb-4">Why Choose Us?</h3>
            </div>
            <div class="col-md-4">
                <div class="card border-0 text-center mb-4">
                    <div class="card-body">
                        <i class="fas fa-truck fa-3x text-primary mb-3"></i>
                        <h4 class="card-title h5">Fast Delivery</h4>
                        <p class="card-text text-muted">Quick and reliable delivery to your doorstep</p>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="card border-0 text-center mb-4">
                    <div class="card-body">
                        <i class="fas fa-shield-alt fa-3x text-primary mb-3"></i>
                        <h4 class="card-title h5">Secure Shopping</h4>
                        <p class="card-text text-muted">Your security is our top priority</p>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="card border-0 text-center mb-4">
                    <div class="card-body">
                        <i class="fas fa-headset fa-3x text-primary mb-3"></i>
                        <h4 class="card-title h5">24/7 Support</h4>
                        <p class="card-text text-muted">Always here to help you</p>
                    </div>
                </div>
            </div>
        </div>

        <div class="row">
            <div class="col-lg-12 text-center">
                <h3 class="mb-4">Our Team</h3>
            </div>
            <div class="col-md-3">
                <div class="card text-center mb-4">
                    <img src="https://images.unsplash.com/photo-1560250097-0b93528c311a?w=500" 
                         class="card-img-top" alt="Team Member">
                    <div class="card-body">
                        <h5 class="card-title">John Doe</h5>
                        <p class="card-text text-muted">CEO & Founder</p>
                    </div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card text-center mb-4">
                    <img src="https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=500" 
                         class="card-img-top" alt="Team Member">
                    <div class="card-body">
                        <h5 class="card-title">Jane Smith</h5>
                        <p class="card-text text-muted">Operations Manager</p>
                    </div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card text-center mb-4">
                    <img src="https://images.unsplash.com/photo-1519085360753-af0119f7cbe7?w=500" 
                         class="card-img-top" alt="Team Member">
                    <div class="card-body">
                        <h5 class="card-title">Mike Johnson</h5>
                        <p class="card-text text-muted">Product Manager</p>
                    </div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card text-center mb-4">
                    <img src="https://images.unsplash.com/photo-1573497019940-1c28c88b4f3e?w=500" 
                         class="card-img-top" alt="Team Member">
                    <div class="card-body">
                        <h5 class="card-title">Sarah Wilson</h5>
                        <p class="card-text text-muted">Customer Support Lead</p>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <?php include 'includes/footer.php'; ?>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
    <script src="assets/js/main.js"></script>
</body>
</html>
